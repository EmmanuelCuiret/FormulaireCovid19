import{b as a,c as b}from"./chunk-FXFZIWDD.js";import"./chunk-RW4GY4BD.js";export{a as GESTURE_CONTROLLER,b as createGesture};
